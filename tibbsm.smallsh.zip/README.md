# README.md for smallsh.c

/********************************************************
*                                                       *
* FILENAME:             README.md                       *
* AUTHOR:               Marc Tibbs                      *
* EMAIL:                tibbsm@oregonstate.edu          *
* CLASS:                CS344 (Winter 2019)             *
* ASSIGNMENT:           Program 3                       *
*                                                       *
********************************************************/

## Compile instructions
* Enter the following commands in your console to compile and run smallsh.c
(1) gcc -o smallsh smallsh.c
(1) ./smallsh